import React from 'react';

function Paragraph(){
  return (
    <div>
      <p>“Hello, I am Mr. Murphy! Nice to finally meet you.</p>
    </div>
  );
};

export default Paragraph;
