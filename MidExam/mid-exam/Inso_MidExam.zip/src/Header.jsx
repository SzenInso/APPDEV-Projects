import React from 'react';

function Header ()  {
  return (
    <header>
        <center><h1><strong>My Midterm Web Examination Page</strong></h1></center>
    </header>
  );
};

export default Header;