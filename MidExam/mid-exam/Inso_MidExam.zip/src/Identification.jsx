import React from 'react';

function Identification(){
  return (
    <div>
      <p>Name: Fhrenne Szen D. Inso<br /></p>
      <p>Age: 19<br /></p>
      <p>Course: BSCS<br /></p>
      <p>Dream Job: Information Systems Analyst<br /></p>
    </div>
  );
};

export default Identification;
